using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using RealtimeRestaurantPOS.Data;
using RealtimeRestaurantPOS.Hubs;
using RealtimeRestaurantPOS.Models;
using System.Linq;
using System.Threading.Tasks;

namespace RealtimeRestaurantPOS.Controllers
{
    public class OrdersController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly IHubContext<OrderHub> _hub;

        public OrdersController(ApplicationDbContext db, IHubContext<OrderHub> hub)
        {
            _db = db;
            _hub = hub;
        }

        public async Task<IActionResult> Index()
        {
            var orders = await _db.Orders.Include(o => o.Items).ThenInclude(oi => oi.MenuItem)
                                         .OrderByDescending(o => o.CreatedAt)
                                         .ToListAsync();
            return View(orders);
        }

        public async Task<IActionResult> Details(int id)
        {
            var order = await _db.Orders.Include(o => o.Items).ThenInclude(oi => oi.MenuItem)
                                        .FirstOrDefaultAsync(o => o.Id == id);
            if (order == null) return NotFound();
            return View(order);
        }

        public async Task<IActionResult> Create()
        {
            ViewBag.MenuItems = await _db.MenuItems.Where(m => m.IsAvailable).ToListAsync();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(string customerName, int[] menuItemIds, int[] quantities)
        {
            if (string.IsNullOrWhiteSpace(customerName) || menuItemIds == null || menuItemIds.Length == 0)
            {
                ModelState.AddModelError("", "Invalid input");
                ViewBag.MenuItems = await _db.MenuItems.Where(m => m.IsAvailable).ToListAsync();
                return View();
            }

            var order = new Order { CustomerName = customerName, Status = OrderStatus.Placed };
            decimal total = 0;

            for (int i = 0; i < menuItemIds.Length; i++)
            {
                var menu = await _db.MenuItems.FindAsync(menuItemIds[i]);
                if (menu == null) continue;
                int qty = quantities.Length > i ? System.Math.Max(1, quantities[i]) : 1;
                var oi = new OrderItem
                {
                    MenuItemId = menu.Id,
                    Quantity = qty,
                    UnitPrice = menu.Price
                };
                order.Items.Add(oi);
                total += menu.Price * qty;
            }

            order.TotalAmount = total;
            _db.Orders.Add(order);
            await _db.SaveChangesAsync();

            // Broadcast new order
            await _hub.Clients.All.SendAsync("ReceiveOrderUpdate", order);

            return RedirectToAction(nameof(Index));
        }

        // Change status (Put this action behind kitchen UI)
        [HttpPost]
        public async Task<IActionResult> ChangeStatus(int id, OrderStatus status)
        {
            var order = await _db.Orders.Include(o => o.Items).FirstOrDefaultAsync(o => o.Id == id);
            if (order == null) return NotFound();
            order.Status = status;
            _db.Orders.Update(order);
            await _db.SaveChangesAsync();

            // broadcast update
            await _hub.Clients.All.SendAsync("ReceiveOrderUpdate", order);

            return Ok(new { success = true });
        }

        // Delete for admin
        [HttpPost]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var order = await _db.Orders.Include(o => o.Items).FirstOrDefaultAsync(o => o.Id == id);
            if (order != null)
            {
                _db.OrderItems.RemoveRange(order.Items);
                _db.Orders.Remove(order);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
