using Microsoft.EntityFrameworkCore;
using RealtimeRestaurantPOS.Models;

namespace RealtimeRestaurantPOS.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) {}

        public DbSet<MenuItem> MenuItems { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<MenuItem>().HasData(
                new MenuItem { Id = 1, Name = "Veg Biryani", Category = "Biryani", Price = 180, IsAvailable = true },
                new MenuItem { Id = 2, Name = "Chicken Biryani", Category = "Biryani", Price = 240, IsAvailable = true },
                new MenuItem { Id = 3, Name = "Coke", Category = "Drinks", Price = 30, IsAvailable = true }
            );
        }
    }
}
