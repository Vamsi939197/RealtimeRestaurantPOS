# RealtimeRestaurantPOS

Simple ASP.NET Core MVC project with EF Core (MySQL) and SignalR for real-time order updates.

## Quick start (local)
1. Update `appsettings.json` with your MySQL connection string.
2. Restore packages: `dotnet restore`
3. Add migration: `dotnet ef migrations add InitialCreate`
4. Update DB: `dotnet ef database update`
5. Run: `dotnet run`

## Codespaces / Devcontainer
This repo includes `.devcontainer` files to run in GitHub Codespaces or Gitpod with a MySQL service.

## Notes
- Replace DB passwords before pushing to public repo.
- Add Authentication/Authorization for production.
