using Microsoft.AspNetCore.SignalR;
using RealtimeRestaurantPOS.Models;
using System.Threading.Tasks;

namespace RealtimeRestaurantPOS.Hubs
{
    public class OrderHub : Hub
    {
        public async Task BroadcastOrderUpdate(Order order)
        {
            await Clients.All.SendAsync("ReceiveOrderUpdate", order);
        }
    }
}
