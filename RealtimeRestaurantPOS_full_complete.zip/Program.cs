using Microsoft.EntityFrameworkCore;
using RealtimeRestaurantPOS.Data;
using RealtimeRestaurantPOS.Hubs;

var builder = WebApplication.CreateBuilder(args);

// Add services to DI
builder.Services.AddControllersWithViews();

// Configure EF Core with MySQL (Pomelo)
var conn = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(conn, ServerVersion.AutoDetect(conn)));

// SignalR
builder.Services.AddSignalR();

var app = builder.Build();

// Ensure DB migrations are applied at startup (optional for dev)
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    db.Database.Migrate();
}

// Middleware
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapHub<OrderHub>("/orderHub");

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
