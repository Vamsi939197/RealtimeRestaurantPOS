using System.ComponentModel.DataAnnotations;

namespace RealtimeRestaurantPOS.Models
{
    public class MenuItem
    {
        public int Id { get; set; }

        [Required] [StringLength(100)]
        public string Name { get; set; }

        [StringLength(50)]
        public string Category { get; set; }

        [Range(0, 100000)]
        public decimal Price { get; set; }

        public bool IsAvailable { get; set; } = true;
    }
}
