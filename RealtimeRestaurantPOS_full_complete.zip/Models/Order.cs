using System.ComponentModel.DataAnnotations;

namespace RealtimeRestaurantPOS.Models
{
    public enum OrderStatus
    {
        Placed,
        Preparing,
        Ready,
        Served
    }

    public class Order
    {
        public int Id { get; set; }

        [Required] [StringLength(100)]
        public string CustomerName { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public OrderStatus Status { get; set; } = OrderStatus.Placed;

        public decimal TotalAmount { get; set; }

        public virtual ICollection<OrderItem> Items { get; set; } = new List<OrderItem>();
    }
}
